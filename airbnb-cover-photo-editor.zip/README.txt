HostGlow

Open index.html in a browser, or deploy the whole folder to any static host.

Features:
- Upload photo from phone
- Brightness / contrast / shadow controls
- Rotation and perspective correction
- Airbnb-style aspect ratio crop
- Export edited JPG

No text or objects are added to the image.
