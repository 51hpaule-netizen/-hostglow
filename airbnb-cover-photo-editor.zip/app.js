const fileInput = document.getElementById('fileInput');
const canvas = document.getElementById('editorCanvas');
const ctx = canvas.getContext('2d');
const emptyState = document.getElementById('emptyState');
const downloadBtn = document.getElementById('downloadBtn');

const controls = {
  brightness: document.getElementById('brightness'),
  contrast: document.getElementById('contrast'),
  highlights: document.getElementById('highlights'),
  shadows: document.getElementById('shadows'),
  saturation: document.getElementById('saturation'),
  rotation: document.getElementById('rotation'),
  perspectiveX: document.getElementById('perspectiveX'),
  perspectiveY: document.getElementById('perspectiveY'),
  zoom: document.getElementById('zoom'),
  aspectRatio: document.getElementById('aspectRatio')
};

const autoEnhanceBtn = document.getElementById('autoEnhanceBtn');
const resetBtn = document.getElementById('resetBtn');

let originalImage = null;
let processedCanvas = document.createElement('canvas');
let processedCtx = processedCanvas.getContext('2d');

const defaults = {
  brightness: 12,
  contrast: 10,
  highlights: 8,
  shadows: 20,
  saturation: 4,
  rotation: 0,
  perspectiveX: 0,
  perspectiveY: 0,
  zoom: 1,
  aspectRatio: '1.5'
};

function setDefaults() {
  Object.entries(defaults).forEach(([key, value]) => {
    controls[key].value = value;
  });
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function loadImageFromFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      originalImage = img;
      emptyState.style.display = 'none';
      downloadBtn.disabled = false;
      render();
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) loadImageFromFile(file);
});

Object.values(controls).forEach(el => {
  el.addEventListener('input', () => {
    if (originalImage) render();
  });
});

autoEnhanceBtn.addEventListener('click', () => {
  controls.brightness.value = 20;
  controls.contrast.value = 12;
  controls.highlights.value = 10;
  controls.shadows.value = 28;
  controls.saturation.value = 6;
  if (originalImage) render();
});

resetBtn.addEventListener('click', () => {
  setDefaults();
  if (originalImage) render();
});

downloadBtn.addEventListener('click', () => {
  if (!originalImage) return;
  const link = document.createElement('a');
  link.download = 'airbnb-cover-edited.jpg';
  link.href = canvas.toDataURL('image/jpeg', 0.92);
  link.click();
});

function rotatePoint(x, y, angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return { x: x * c - y * s, y: x * s + y * c };
}

function computeTransformedCorners(w, h, angle, px, py, zoom) {
  const hw = (w / 2) / zoom;
  const hh = (h / 2) / zoom;
  let corners = [
    { x: -hw, y: -hh },
    { x: hw, y: -hh },
    { x: hw, y: hh },
    { x: -hw, y: hh }
  ];

  corners = corners.map(p => rotatePoint(p.x, p.y, angle));

  const topScale = 1 - py;
  const bottomScale = 1 + py;
  const leftScale = 1 - px;
  const rightScale = 1 + px;

  corners = corners.map((p, i) => {
    const isTop = i === 0 || i === 1;
    const isLeft = i === 0 || i === 3;
    return {
      x: p.x * (isLeft ? leftScale : rightScale),
      y: p.y * (isTop ? topScale : bottomScale)
    };
  });

  return corners;
}

function drawImageQuad(img, dstCorners) {
  const srcW = img.width;
  const srcH = img.height;

  const srcCorners = [
    { x: 0, y: 0 },
    { x: srcW, y: 0 },
    { x: srcW, y: srcH },
    { x: 0, y: srcH }
  ];

  drawTriangle(img, srcCorners[0], srcCorners[1], srcCorners[2], dstCorners[0], dstCorners[1], dstCorners[2]);
  drawTriangle(img, srcCorners[0], srcCorners[2], srcCorners[3], dstCorners[0], dstCorners[2], dstCorners[3]);
}

function drawTriangle(img, s0, s1, s2, d0, d1, d2) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(d0.x, d0.y);
  ctx.lineTo(d1.x, d1.y);
  ctx.lineTo(d2.x, d2.y);
  ctx.closePath();
  ctx.clip();

  const denom = s0.x * (s1.y - s2.y) + s1.x * (s2.y - s0.y) + s2.x * (s0.y - s1.y);
  if (Math.abs(denom) < 1e-6) {
    ctx.restore();
    return;
  }

  const m11 = (d0.x * (s1.y - s2.y) + d1.x * (s2.y - s0.y) + d2.x * (s0.y - s1.y)) / denom;
  const m12 = (d0.y * (s1.y - s2.y) + d1.y * (s2.y - s0.y) + d2.y * (s0.y - s1.y)) / denom;
  const m21 = (d0.x * (s2.x - s1.x) + d1.x * (s0.x - s2.x) + d2.x * (s1.x - s0.x)) / denom;
  const m22 = (d0.y * (s2.x - s1.x) + d1.y * (s0.x - s2.x) + d2.y * (s1.x - s0.x)) / denom;
  const dx = (d0.x * (s1.x * s2.y - s2.x * s1.y) + d1.x * (s2.x * s0.y - s0.x * s2.y) + d2.x * (s0.x * s1.y - s1.x * s0.y)) / denom;
  const dy = (d0.y * (s1.x * s2.y - s2.x * s1.y) + d1.y * (s2.x * s0.y - s0.x * s2.y) + d2.y * (s0.x * s1.y - s1.x * s0.y)) / denom;

  ctx.transform(m11, m12, m21, m22, dx, dy);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

function applyToneAdjustments(sourceCanvas) {
  const imgData = processedCtx.getImageData(0, 0, sourceCanvas.width, sourceCanvas.height);
  const data = imgData.data;

  const brightness = parseFloat(controls.brightness.value);
  const contrast = parseFloat(controls.contrast.value);
  const highlights = parseFloat(controls.highlights.value);
  const shadows = parseFloat(controls.shadows.value);
  const saturation = parseFloat(controls.saturation.value) / 100;

  const contrastFactor = (259 * (contrast + 255)) / (255 * (259 - contrast));

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const shadowBoost = (1 - luminance / 255) * shadows * 0.9;
    const highlightBoost = (luminance / 255) * highlights * 0.6;

    r += brightness + shadowBoost + highlightBoost;
    g += brightness + shadowBoost + highlightBoost;
    b += brightness + shadowBoost + highlightBoost;

    r = contrastFactor * (r - 128) + 128;
    g = contrastFactor * (g - 128) + 128;
    b = contrastFactor * (b - 128) + 128;

    const gray = 0.2989 * r + 0.587 * g + 0.114 * b;
    r = gray + (r - gray) * (1 + saturation);
    g = gray + (g - gray) * (1 + saturation);
    b = gray + (b - gray) * (1 + saturation);

    data[i] = clamp(Math.round(r), 0, 255);
    data[i + 1] = clamp(Math.round(g), 0, 255);
    data[i + 2] = clamp(Math.round(b), 0, 255);
  }

  processedCtx.putImageData(imgData, 0, 0);
}

function render() {
  if (!originalImage) return;

  const targetRatioValue = controls.aspectRatio.value;
  const outW = 1200;
  let outH = 800;
  if (targetRatioValue !== 'free') {
    outH = Math.round(outW / parseFloat(targetRatioValue));
  }

  canvas.width = outW;
  canvas.height = outH;
  ctx.clearRect(0, 0, outW, outH);
  ctx.fillStyle = '#0f1115';
  ctx.fillRect(0, 0, outW, outH);

  processedCanvas.width = originalImage.width;
  processedCanvas.height = originalImage.height;
  processedCtx.clearRect(0, 0, processedCanvas.width, processedCanvas.height);
  processedCtx.drawImage(originalImage, 0, 0);
  applyToneAdjustments(processedCanvas);

  const rotation = parseFloat(controls.rotation.value) * Math.PI / 180;
  const perspectiveX = parseFloat(controls.perspectiveX.value) / 100;
  const perspectiveY = parseFloat(controls.perspectiveY.value) / 100;
  const zoom = parseFloat(controls.zoom.value);

  const corners = computeTransformedCorners(
    processedCanvas.width,
    processedCanvas.height,
    rotation,
    perspectiveX,
    perspectiveY,
    zoom
  );

  const xs = corners.map(p => p.x);
  const ys = corners.map(p => p.y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);

  const quadW = maxX - minX;
  const quadH = maxY - minY;
  const scale = Math.min(outW / quadW, outH / quadH) * 0.98;
  const offsetX = outW / 2;
  const offsetY = outH / 2;

  const dstCorners = corners.map(p => ({
    x: (p.x - (minX + maxX) / 2) * scale + offsetX,
    y: (p.y - (minY + maxY) / 2) * scale + offsetY
  }));

  drawImageQuad(processedCanvas, dstCorners);
}

setDefaults();
